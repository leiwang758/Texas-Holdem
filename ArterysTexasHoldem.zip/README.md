# Texas-Holdem
This is texas hold'em ranking program wrote by Lei Wang

# Framework
Python 3

# Run Program
 - python3 texas_holdem.py
 - input community card and player hand of as required
 - program will rank each player and print out the ranking

