# Texas-Holdem
This is texas hold'em ranking program wrote by Lei Wang

# Framework
Python 3

# Run Program
 - In linux, run python3 texas_holdem.py
 - Input the community cards and players' hand of cards as required
 - Program will rank each player and print out the ranking info

